import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_logs(filename='login_logs.csv', n_rows=1000):
    ips = [f"192.168.1.{i}" for i in range(1, 10)]
    users = ["admin", "user1", "guest", "root"]
    data = []
    start_time = datetime.now()
    
    # 1. Generate Normal Traffic
    for i in range(n_rows):
        ip = np.random.choice(ips)
        status = "success" if np.random.random() > 0.1 else "failed"
        timestamp = start_time + timedelta(seconds=i * 60) # Spaced out
        data.append([timestamp, ip, np.random.choice(users), status])
    
    # 2. Generate CRITICAL ATTACK (100 fails in 1 minute)
    attacker_ip = "172.16.0.100"
    attack_start = start_time + timedelta(minutes=5)
    for i in range(100):
        timestamp = attack_start + timedelta(seconds=i * 0.5) # Very rapid
        data.append([timestamp, attacker_ip, "admin", "failed"])
    
    df = pd.DataFrame(data, columns=['timestamp', 'source_ip', 'username', 'status'])
    df = df.sort_values('timestamp')
    df.to_csv(filename, index=False)
    print(f"Generated {filename} with a CRITICAL attack from 172.16.0.100.")

if __name__ == "__main__":
    generate_logs()