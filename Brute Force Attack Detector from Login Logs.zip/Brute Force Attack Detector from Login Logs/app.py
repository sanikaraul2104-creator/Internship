from flask import Flask, request, render_template_string, Response
import pandas as pd
import pickle
import os
from datetime import datetime

app = Flask(__name__)

# REINSTATED: Previous UI Style with added Severity Classes
HTML_PAGE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOC Dashboard | Brute Force Detector</title>
    <style>
        :root {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --primary-blue: #3b82f6;
            --danger-red: #ef4444;
            --success-green: #10b981;
            --text-main: #f8fafc;
        }
        body { font-family: 'Segoe UI', sans-serif; background-color: var(--bg-color); color: var(--text-main); margin: 0; display: flex; flex-direction: column; align-items: center; min-height: 100vh; }
        .navbar { width: 100%; background-color: var(--card-bg); padding: 1rem 2rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border-bottom: 2px solid var(--primary-blue); box-sizing: border-box;}
        .container { width: 90%; max-width: 1200px; margin-top: 30px; }
        .card { background: var(--card-bg); padding: 25px; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); margin-bottom: 30px; }
        h2 { margin-top: 0; color: var(--primary-blue); letter-spacing: 1px; }
        
        /* Severity Banner Styles */
        .severity-banner { padding: 20px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; text-align: center; border-left: 10px solid; }
        .high-severity { background: #450a0a; color: #fecaca; border-color: var(--danger-red); }
        .low-severity { background: #064e3b; color: #d1fae5; border-color: var(--success-green); }

        input[type="file"] { background: #334155; padding: 10px; border-radius: 6px; border: 1px dashed #64748b; color: white; cursor: pointer; }
        input[type="submit"], .btn-report { background: var(--primary-blue); color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: bold; transition: 0.3s; margin-top:10px; text-decoration:none; display:inline-block;}
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; overflow: hidden; border-radius: 8px; }
        th { background-color: #334155; color: var(--primary-blue); text-align: left; padding: 15px; text-transform: uppercase; font-size: 12px; }
        td { padding: 15px; border-bottom: 1px solid #334155; font-family: 'Courier New', monospace; }
        tr:hover { background-color: #2d3748; }
        
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .badge-attack { background-color: var(--danger-red); color: white; }
        .badge-safe { background-color: var(--success-green); color: white; }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="margin:0;">🛡️ CyberGuard <span style="font-weight:100; opacity:0.7;">| Brute Force Detection Engine</span></h3>
    </div>

    <div class="container">
        <div class="card">
            <h2>Log Analysis Center</h2>
            <p style="opacity:0.7;">Upload server authentication logs (CSV format) to detect anomalous behavior.</p>
            <form method="post" enctype="multipart/form-data">
                <input type="file" name="file" required>
                <input type="submit" value="RUN ML ENGINE">
            </form>
        </div>

        {% if analyzed %}
            {% if attack_found %}
                <div class="severity-banner high-severity">
                    🚨 CRITICAL THREAT DETECTED: Automated Brute Force Patterns Identified
                </div>
            {% else %}
                <div class="severity-banner low-severity">
                    ✅ SYSTEM SECURE: All Traffic Analysis aligns with Normal Behavior
                </div>
            {% endif %}

            <div class="card">
                <h2 style="color: {% if attack_found %}var(--danger-red){% else %}var(--primary-blue){% endif %};">
                    Threat Detection Report
                </h2>
                <div style="overflow-x:auto;">
                    {{ tables|safe }}
                </div>

                <div style="margin-top: 25px; border-top: 1px solid #334155; padding-top: 20px;">
                    <h3>📄 SOC Actions</h3>
                    <form action="/download_report" method="post">
                        <input type="hidden" name="report_content" value="{{ report_data }}">
                        <input type="submit" class="btn-report" value="EXPORT INCIDENT SUMMARY (.TXT)">
                    </form>
                </div>
            </div>
        {% endif %}
    </div>
</body>
</html>
'''

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    tables = None
    analyzed = False
    attack_found = False
    report_data = ""

    if request.method == 'POST':
        file = request.files['file']
        if file and os.path.exists('bf_model.pkl'):
            with open('bf_model.pkl', 'rb') as f:
                model = pickle.load(f)
            
            df = pd.read_csv(file)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df['is_failed'] = (df['status'] == 'failed').astype(int)
            
            processed = df.groupby(['source_ip', pd.Grouper(key='timestamp', freq='1min')]).agg(
                attempts_per_min=('status', 'count'),
                unique_users=('username', 'nunique'),
                failed_count=('is_failed', 'sum')
            ).reset_index()
            processed['fail_ratio'] = (processed['failed_count'] / processed['attempts_per_min']).round(2)
            
            # Prediction
            features = processed[['attempts_per_min', 'unique_users', 'fail_ratio']]
            processed['Pred'] = model.predict(features)
            
            # Severity Logic
            if 1 in processed['Pred'].values:
                attack_found = True
            
            # UI Formatting
            results = processed.sort_values(['Pred', 'attempts_per_min'], ascending=False).copy()
            results['Status'] = results['Pred'].apply(
                lambda x: '<span class="badge badge-attack">CRITICAL ATTACK</span>' if x == 1 
                else '<span class="badge badge-safe">NORMAL</span>'
            )
            
            # Prepare Report Data
            suspects = results[results['Pred'] == 1]['source_ip'].unique()
            report_data = f"--- SOC BRUTE FORCE INCIDENT REPORT ---\nGenerated: {datetime.now()}\nSeverity: {'HIGH' if attack_found else 'LOW'}\nFlagged IPs: {list(suspects)}\nAnalysis: Based on XGBoost behavioral classification."

            # Final Table
            display_df = results[['source_ip', 'timestamp', 'attempts_per_min', 'fail_ratio', 'Status']]
            display_df.columns = ['IP Address', 'Time Window', 'Attempts/Min', 'Fail Ratio', 'Threat Level']
            tables = display_df.to_html(classes='data', index=False, escape=False)
            analyzed = True
                
    return render_template_string(HTML_PAGE, tables=tables, analyzed=analyzed, attack_found=attack_found, report_data=report_data)

@app.route('/download_report', methods=['POST'])
def download_report():
    content = request.form.get('report_content', 'No data available.')
    return Response(content, mimetype="text/plain",
                    headers={"Content-disposition": "attachment; filename=SOC_Analysis_Report.txt"})

if __name__ == '__main__':
    app.run(port=5000, debug=True)