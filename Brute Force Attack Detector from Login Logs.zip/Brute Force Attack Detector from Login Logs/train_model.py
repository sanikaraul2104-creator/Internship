import pandas as pd
from xgboost import XGBClassifier
import pickle

def engineer_features(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['is_failed'] = (df['status'] == 'failed').astype(int)
    
    features = df.groupby(['source_ip', pd.Grouper(key='timestamp', freq='1min')]).agg(
        attempts_per_min=('status', 'count'),
        unique_users=('username', 'nunique'),
        failed_count=('is_failed', 'sum')
    ).reset_index()
    
    features['fail_ratio'] = features['failed_count'] / features['attempts_per_min']
    # Label: > 10 attempts/min + > 90% failure = Attack
    features['label'] = ((features['attempts_per_min'] > 10) & (features['fail_ratio'] > 0.9)).astype(int)
    return features

def train():
    df = pd.read_csv('login_logs.csv')
    data = engineer_features(df)
    
    X = data[['attempts_per_min', 'unique_users', 'fail_ratio']]
    y = data['label']
    
    # scale_pos_weight=10 tells the model to focus heavily on the attack class
    model = XGBClassifier(n_estimators=100, scale_pos_weight=10, eval_metric='logloss')
    model.fit(X, y)
    
    with open('bf_model.pkl', 'wb') as f:
        pickle.dump(model, f)
    print(f"Model trained! Found {data['label'].sum()} attack windows.")

if __name__ == "__main__":
    train()